import React from 'react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import Buy from './pages/Buy.jsx';
import Sell from './pages/Sell.jsx';
import Account from './pages/Account.jsx';
import Login from './pages/Login.jsx';
import Register from './pages/Register.jsx';

export default function App(){
  return (
    <Router>
      <div className='min-h-screen bg-gray-900 text-white'>
        <header className='p-4 bg-gray-800 flex justify-between'>
          <h1 className='text-xl font-bold'>GameID Exchange</h1>
          <nav className='space-x-4'>
            <Link to='/'>Home</Link>
            <Link to='/buy'>Buy</Link>
            <Link to='/sell'>Sell</Link>
            <Link to='/account'>Account</Link>
            <Link to='/login'>Login</Link>
          </nav>
        </header>
        <main className='p-6'>
          <Routes>
            <Route path='/' element={<div>Welcome to GameID Exchange</div>} />
            <Route path='/buy' element={<Buy/>} />
            <Route path='/sell' element={<Sell/>} />
            <Route path='/account' element={<Account/>} />
            <Route path='/login' element={<Login/>} />
            <Route path='/register' element={<Register/>} />
          </Routes>
        </main>
      </div>
    </Router>
  );
}
