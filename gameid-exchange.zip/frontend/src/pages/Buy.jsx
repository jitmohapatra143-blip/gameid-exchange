import React, {useEffect, useState} from 'react';
export default function Buy(){
  const [listings, setListings] = useState([]);
  useEffect(()=>{ fetch('http://localhost:4000/api/listings').then(r=>r.json()).then(setListings).catch(()=>{}); },[]);
  return (<div className='grid grid-cols-1 md:grid-cols-2 gap-4'>
    {listings.map(l=>(
      <div key={l.id} className='bg-gray-800 p-4 rounded'>
        <h3 className='text-lg font-bold'>{l.game} — {l.rank}</h3>
        <p className='text-sm text-gray-400'>{l.description}</p>
        <p className='mt-2 font-semibold'>${l.price}</p>
        <p className='text-xs text-gray-500'>Seller: {l.seller_name}</p>
        <button className='mt-3 bg-blue-600 px-3 py-2 rounded'>Buy Now</button>
      </div>
    ))}
  </div>);
}
