import React,{useEffect,useState} from 'react';
export default function Account(){
  const [data,setData]=useState({listings:[],transactions:[]});
  useEffect(()=>{ const token=localStorage.getItem('token'); if(!token) return; fetch('http://localhost:4000/api/account',{headers:{Authorization:'Bearer '+token}}).then(r=>r.json()).then(setData).catch(()=>{}); },[]);
  return (<div>
    <h2>My Listings</h2>
    {data.listings.map(l=>(<div key={l.id} className='bg-gray-800 p-3 rounded mb-2'>{l.game} - {l.rank} (${l.price}) [{l.status}]</div>))}
    <h2 className='mt-6'>My Transactions</h2>
    {data.transactions.map(t=>(<div key={t.id} className='bg-gray-800 p-3 rounded mb-2'>{t.game} - ${t.amount} [{t.status}]</div>))}
  </div>);
}
