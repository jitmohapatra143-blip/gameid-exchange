import React, {useState} from 'react';
export default function Sell(){
  const [form,setForm]=useState({game:'',rank:'',price:'',description:''});
  const change=(e)=>setForm({...form,[e.target.name]:e.target.value});
  const submit=async(e)=>{ e.preventDefault(); const token=localStorage.getItem('token'); const res=await fetch('http://localhost:4000/api/listings',{method:'POST',headers:{'Content-Type':'application/json','Authorization':'Bearer '+token},body:JSON.stringify(form)}); if(res.ok){alert('Listing created'); setForm({game:'',rank:'',price:'',description:''});} else {const d=await res.json(); alert(d.error||'Error');}};
  return (<form onSubmit={submit} className='max-w-md'>
    <input name='game' placeholder='Game' value={form.game} onChange={change} className='w-full mb-2 p-2'/>
    <input name='rank' placeholder='Rank' value={form.rank} onChange={change} className='w-full mb-2 p-2'/>
    <input name='price' placeholder='Price' value={form.price} onChange={change} className='w-full mb-2 p-2'/>
    <textarea name='description' placeholder='Description' value={form.description} onChange={change} className='w-full mb-2 p-2'/>
    <button className='bg-blue-600 px-4 py-2 rounded'>Submit Listing</button>
  </form>);
}
