GameID Exchange - Ready to run scaffold

Instructions:

1) Backend
- cd backend
- Copy .env.example to .env and set DATABASE_URL, EMAIL_USER, EMAIL_PASS, JWT_SECRET
- Install: npm install
- Initialize DB: psql -U youruser -d gameid_exchange -f schema.sql
- (optional) Seed: psql -U youruser -d gameid_exchange -f seed.sql
- Start backend: npm start

2) Frontend
- cd frontend
- Install: npm install
- Start dev server: npx vite

Notes:
- Backend runs on port 4000
- Frontend expects API at http://localhost:4000
