import jwt from "jsonwebtoken";
import { getPool } from "../config/db.mjs";

export async function requireAuth(req, res, next) {
  const auth = req.headers.authorization;
  if (!auth) return res.status(401).json({ error: "missing_token" });
  const token = auth.split(" ")[1];
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET || "dev_secret");
    const pool = getPool();
    const result = await pool.query("SELECT id, username, display_name, is_admin FROM users WHERE id=$1", [decoded.sub || decoded.userId || decoded.id]);
    req.user = result.rows[0];
    if (!req.user) return res.status(401).json({ error: "invalid_token" });
    next();
  } catch (err) {
    res.status(401).json({ error: "invalid_or_expired_token" });
  }
}
