import express from "express";
import { getPool } from "../config/db.mjs";

const router = express.Router();

router.get("/", async (req, res, next) => {
  try {
    const userId = req.user.id;
    const pool = getPool();
    const listings = await pool.query("SELECT id, game, rank, price, status, created_at FROM listings WHERE user_id=$1 ORDER BY created_at DESC", [userId]);
    const transactions = await pool.query(`SELECT t.id, t.amount, t.status, t.created_at, l.game, l.rank FROM transactions t JOIN listings l ON t.listing_id = l.id WHERE t.buyer_id=$1 OR t.seller_id=$1 ORDER BY t.created_at DESC`, [userId]);
    res.json({ listings: listings.rows, transactions: transactions.rows });
  } catch (err) { next(err); }
});

export default router;
