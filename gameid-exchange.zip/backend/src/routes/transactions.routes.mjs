import express from "express";
import { getPool } from "../config/db.mjs";
import { requireAuth } from "../middleware/auth.mjs";
import { sendEmail } from "../emails/mailer.mjs";
import { transactionTemplate } from "../emails/transaction.mjs";

const router = express.Router();

router.post("/", requireAuth, async (req, res, next) => {
  try {
    const { listingId } = req.body;
    const buyerId = req.user.id;
    const pool = getPool();
    const lr = await pool.query("SELECT * FROM listings WHERE id=$1 AND status='active'", [listingId]);
    const listing = lr.rows[0];
    if (!listing) return res.status(404).json({ error: "not_found" });
    if (listing.user_id === buyerId) return res.status(400).json({ error: "cannot_buy_own_listing" });
    const tr = await pool.query("INSERT INTO transactions (listing_id, buyer_id, seller_id, amount, status) VALUES ($1,$2,$3,$4,'pending') RETURNING *", [listing.id, buyerId, listing.user_id, listing.price]);
    await pool.query("UPDATE listings SET status='sold' WHERE id=$1", [listing.id]);
    // email notifications
    try {
      await sendEmail(req.user.email, "🔔 Purchase Created", transactionTemplate("pending", listing.price));
      const sellerRes = await pool.query("SELECT email, display_name FROM users WHERE id=$1", [listing.user_id]);
      if (sellerRes.rows[0]) {
        await sendEmail(sellerRes.rows[0].email, "🔔 Your listing was purchased", transactionTemplate("pending", listing.price));
      }
    } catch(e){ console.error("email error", e); }
    res.json(tr.rows[0]);
  } catch (err) { next(err); }
});

export default router;
