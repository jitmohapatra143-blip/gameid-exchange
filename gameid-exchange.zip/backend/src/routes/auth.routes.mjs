import express from "express";
import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";
import { getPool } from "../config/db.mjs";
import { sendEmail } from "../emails/mailer.mjs";
import { registrationTemplate } from "../emails/registration.mjs";

const router = express.Router();

router.post("/register", async (req, res, next) => {
  try {
    const { username, displayName, password, email } = req.body;
    if (!username || !password || !email) return res.status(400).json({ error: "missing_fields" });
    const hashed = await bcrypt.hash(password, 12);
    const pool = getPool();
    const result = await pool.query("INSERT INTO users (username, display_name, email, password_hash) VALUES ($1,$2,$3,$4) RETURNING id, username, display_name, email", [username, displayName||username, email, hashed]);
    const user = result.rows[0];
    // send welcome email
    try {
      await sendEmail(user.email, "🎉 Welcome to GameID Exchange", registrationTemplate(user.display_name));
    } catch(e){ console.error("email error", e); }
    res.json({ user });
  } catch (err) {
    next(err);
  }
});

router.post("/login", async (req, res, next) => {
  try {
    const { email, password } = req.body;
    const pool = getPool();
    const result = await pool.query("SELECT * FROM users WHERE email=$1", [email]);
    const user = result.rows[0];
    if (!user) return res.status(401).json({ error: "invalid_credentials" });
    const ok = await bcrypt.compare(password, user.password_hash);
    if (!ok) return res.status(401).json({ error: "invalid_credentials" });
    const token = jwt.sign({ sub: user.id, email: user.email, is_admin: user.is_admin }, process.env.JWT_SECRET || "dev_secret", { expiresIn: "7d" });
    res.json({ token, user: { id: user.id, username: user.username, displayName: user.display_name, email: user.email, is_admin: user.is_admin } });
  } catch (err) {
    next(err);
  }
});

export default router;
