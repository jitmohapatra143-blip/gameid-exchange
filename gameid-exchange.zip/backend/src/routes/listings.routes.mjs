import express from "express";
import { getPool } from "../config/db.mjs";
import { requireAuth } from "../middleware/auth.mjs";
import { sendEmail } from "../emails/mailer.mjs";
import { listingTemplate } from "../emails/listing.mjs";

const router = express.Router();

router.get("/", async (req, res, next) => {
  try {
    const pool = getPool();
    const result = await pool.query(`SELECT l.id, l.game, l.rank, l.price, l.description, l.status, l.created_at, u.display_name AS seller_name FROM listings l JOIN users u ON l.user_id = u.id WHERE l.status='active' ORDER BY l.created_at DESC`);
    res.json(result.rows);
  } catch (err) { next(err); }
});

router.post("/", requireAuth, async (req, res, next) => {
  try {
    const { game, rank, price, description } = req.body;
    const userId = req.user.id;
    if (!game || !price) return res.status(400).json({ error: "missing_fields" });
    const pool = getPool();
    const r = await pool.query("INSERT INTO listings (user_id, game, rank, price, description, status) VALUES ($1,$2,$3,$4,$5,'active') RETURNING *", [userId, game, rank, price, description]);
    const listing = r.rows[0];
    // send listing email to seller
    try {
      await sendEmail(req.user.email, `📢 Your ${game} listing is live`, listingTemplate(req.user.display_name, game, price));
    } catch(e){ console.error("email send failed", e); }
    res.json(listing);
  } catch (err) { next(err); }
});

export default router;
