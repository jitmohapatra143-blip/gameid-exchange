import pkg from "pg";
const { Pool } = pkg;
let pool;
export function getPool() {
  if (!pool) {
    pool = new Pool({
      connectionString: process.env.DATABASE_URL || "postgres://postgres:postgres@localhost:5432/gameid_exchange"
    });
  }
  return pool;
}
