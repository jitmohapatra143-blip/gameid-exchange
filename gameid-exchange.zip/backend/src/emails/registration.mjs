export function registrationTemplate(displayName) {
  return `
  <div style="font-family: Arial, sans-serif; background: #f4f4f4; padding: 20px;">
    <div style="max-width: 600px; margin: auto; background: #ffffff; border-radius: 8px; overflow: hidden;">
      <div style="background: #2563eb; color: #fff; padding: 20px; text-align: center;">
        <h1>🎉 Welcome, ${displayName}!</h1>
      </div>
      <div style="padding: 20px; color: #333;">
        <p>Thank you for registering at <b>GameID Exchange</b>.</p>
        <p>You can now buy and sell gaming accounts securely.</p>
        <p style="margin-top:20px;">Happy trading,<br>GameID Exchange Team</p>
      </div>
    </div>
  </div>
  `;
}
