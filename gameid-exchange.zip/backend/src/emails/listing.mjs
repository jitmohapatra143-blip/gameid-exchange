export function listingTemplate(displayName, game, price) {
  return `
  <div style="font-family: Arial, sans-serif; background: #f4f4f4; padding: 20px;">
    <div style="max-width: 600px; margin: auto; background: #ffffff; border-radius: 8px; overflow: hidden;">
      <div style="background: #2563eb; color: #fff; padding: 20px; text-align: center;">
        <h1>📢 New Listing Created</h1>
      </div>
      <div style="padding: 20px; color: #333;">
        <p>Hello <b>${displayName}</b>,</p>
        <p>Your account listing has been created successfully:</p>
        <ul>
          <li><b>Game:</b> ${game}</li>
          <li><b>Price:</b> $${price}</li>
        </ul>
        <p style="margin-top:20px;">Best of luck with your sale!<br>GameID Exchange Team</p>
      </div>
    </div>
  </div>
  `;
}
