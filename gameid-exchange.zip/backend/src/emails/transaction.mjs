export function transactionTemplate(status, amount) {
  let color = "#f97316";
  let title = "⏳ Transaction Pending";
  if (status.toLowerCase().includes("success")) { color="#16a34a"; title = "✅ Payment Confirmed"; }
  if (status.toLowerCase().includes("failed") || status.toLowerCase().includes("cancel")) { color="#dc2626"; title = "❌ Transaction Failed"; }
  return `
  <div style="font-family: Arial, sans-serif; background: #f4f4f4; padding: 20px;">
    <div style="max-width: 600px; margin: auto; background: #ffffff; border-radius: 8px; overflow: hidden;">
      <div style="background: ${color}; color: #fff; padding: 20px; text-align: center;">
        <h1>${title}</h1>
      </div>
      <div style="padding: 20px; color: #333;">
        <p>Your transaction of <b>$${amount}</b> is currently marked as: <b>${status}</b>.</p>
        <p style="margin-top:20px;">Thank you for using GameID Exchange!</p>
      </div>
    </div>
  </div>
  `;
}
