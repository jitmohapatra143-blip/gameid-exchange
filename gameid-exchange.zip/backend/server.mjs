import express from "express";
import cors from "cors";
import bodyParser from "body-parser";
import { createServer } from "http";
import { Server } from "socket.io";

import authRoutes from "./src/routes/auth.routes.mjs";
import listingsRoutes from "./src/routes/listings.routes.mjs";
import accountRoutes from "./src/routes/account.routes.mjs";
import transactionsRoutes from "./src/routes/transactions.routes.mjs";

import { requireAuth } from "./src/middleware/auth.mjs";

const app = express();
app.use(cors());
app.use(bodyParser.json());

app.use("/api/auth", authRoutes);
app.use("/api/listings", listingsRoutes);
app.use("/api/account", requireAuth, accountRoutes);
app.use("/api/transactions", transactionsRoutes);

app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ error: "server_error" });
});

const httpServer = createServer(app);
const io = new Server(httpServer, { cors: { origin: "*" } });

export { io };

httpServer.listen(4000, () => console.log("Backend running on http://localhost:4000"));
