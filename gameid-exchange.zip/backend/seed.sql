INSERT INTO users (username, display_name, email, password_hash, is_admin) VALUES
('seller01','ProSeller','seller01@example.com','$2b$12$5c1NacA5dEZoFf1Z8fwA7OsJq8nm1C9aNnQCe0jVpyCNY78HDZTne', true),
('buyer01','QuickBuyer','buyer01@example.com','$2b$12$5c1NacA5dEZoFf1Z8fwA7OsJq8nm1C9aNnQCe0jVpyCNY78HDZTne', false);

INSERT INTO listings (user_id, game, rank, price, description) VALUES
(1, 'Valorant', 'Diamond 2', 150.00, 'Diamond 2 account with rare skins.'),
(1, 'League of Legends', 'Platinum IV', 120.00, 'Platinum account with 80+ champions and skins.');

INSERT INTO transactions (listing_id, buyer_id, seller_id, amount, status) VALUES
(1, 2, 1, 150.00, 'success');
